#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <pthread.h>


#define NUM 4
#define MAX 10000000

void *searchPrime(void *args) {
	int offset = *(int*)args;

	long i;
	long j;
	int isPrime;
	int step = NUM * 2;
	#pragma omp parallel schedule(static,1) 
	for (i = 3 + offset; i<MAX; i += step) {

		if (i % 2) {

			isPrime = 1;

			for (j = 2; j <= sqrt(i); j++) {

				if (i % j == 0) {

					isPrime = 0;

					break;

				}
			}
		}

	}
	return NULL;
}

int main() {
	pthread_t t_array[NUM];

	int bound[NUM];

	int start, end;

	start = clock();

	int i;

	for (i = 0; i<NUM; i++) {
		bound[i] = i * 2;
		pthread_create(t_array + i, NULL, searchPrime, (void *)(bound + i));
	}
	
	for (i = 0; i<NUM; i++) {
		pthread_join(t_array[i], NULL);
	}

	end = clock();

	unsigned timeuse = (end - start) * 1.0 / CLOCKS_PER_SEC * 1000;
	printf("Running time is around %ld minSecs\n", timeuse);

	return 0;
}